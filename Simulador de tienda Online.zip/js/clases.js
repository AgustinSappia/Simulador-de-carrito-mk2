
class productos{
    constructor(id,nombre,precio,stock){
        this.id = id,
        this.nombre=nombre,
        this.precio=precio,
        this.stock=stock,
        this.destacado=1
    }
   
}


//-----------------------------------------------------------------------
class Usuarios{
    constructor(nombre,contraseña,admin){
        this.nombre = nombre,
        this.contraseña = contraseña,
        this.admin = admin
    }

   
}